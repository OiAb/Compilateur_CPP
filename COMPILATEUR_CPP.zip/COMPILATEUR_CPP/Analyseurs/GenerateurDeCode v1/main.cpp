//OUIJDANE Abchir
#include <iostream>
#include "generateur_code.h"
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
using namespace std;
int main()
{
    //string str="entier e[10],entier j,struct var{entier k,entier m;};struct bar{entier h,entier g;};entier bar;somme(entier a,entier b)entier d[10];{d=a+somme;retour d;}main()entier somme,struct var{entier i,entier p;};{e[0]= 153;var=lire();ecrire(c);}";
    string str=" ";
    generateur_code Gen(str);Gen.readfichier();//Gen.uniteSuivante();
    return 0;
}
