//OUIJDANE Abchir
#include <iostream>
#include "Lexical.h"
#include <string>
#include <fstream>
using namespace std;

int main()
{
    string str="entier e;main(){e = 153;}";
    Lexical LexicalTest(str);LexicalTest.readfichier();LexicalTest.uniteSuivante();
    return 0;

}
