#ifndef LEXICAL_H
#define LEXICAL_H
#include <string>
#include <vector>
using namespace std;
enum TUnite{
    BIN_OP,
    PT,
    BIN_COMP,
    NON,
    COMMENT,
    AND,
    OR,
    AFF,
    CROCH_OUV,
    CROCH_FER,
    PAR_OUV,
    PAR_FER,
    VERG,
    ACC_OUV,
    ACC_FER,
    PT_VER,
    MOT_CLE,
    MOT_RESERVE,
    NOMBRE,
    IDENT,FIN,
    VAR,
    VARSTRUCT,
    VARTAB,
    VARDESTRUCT,
    AUTRE,ERROR
};
typedef struct TUniteLexical{
    string UL;
    int attribut;
}TUniteLexical;
class Lexical
{
    public:
        Lexical(string s);
        void readfichier();
        void fin();
        void affiche(TUniteLexical ul1);
        void ULIdentif(string lexeme);
        void uniteSuivante();
        bool estBlanc(char c);
        int getIndexIdentif(string stringToFind, vector<string> stringArray);
        int getIndex(string stringToFind, vector<string> stringArray);
        int estMotcle(string lexeme);
        int estMotreserve(string lexeme);
        char lc();
    protected:

    private:
    char c=' ';string Str;int test=0;
    vector<int> tokens;
    //table des mot-cl�s
    vector<string> motsCles={"sinon","alors","si","tantque","faire","entier","retour","structure"};
    //table des mot-r�s�rv�s
    vector<string> motsReserves={"lire","ecrire","main"};

    //table des operateurs binaires
    vector<string> binOp={"+","-","*","/"};

    //table des comparateurs binaires
    vector<string> binComp={"<",">","<=",">=","==","!="};

    // liste des identifiants
    vector<string> identifiants;

};

#endif // LEXICAL_H
