//OUIJDANE Abchir
#include <iostream>
#include "analyseur_syntaxique.h"
#include <string>
#include <fstream>
using namespace std;

int main()
{
    string str="entier e[10],struct var{entier k;entier m;};main){e[0] = 153 ecrire(e[0])}";
    analyseur_syntaxique Syntax(str);Syntax.readfichier();Syntax.uniteSuivante();
    return 0;

}
