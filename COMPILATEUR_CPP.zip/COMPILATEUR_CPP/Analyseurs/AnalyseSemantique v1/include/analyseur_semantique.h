#ifndef ANALYSEUR_SEMANTIQUE_H
#define ANALYSEUR_SEMANTIQUE_H
//#include "analyseur_lexical.h"
#include <string>
#include <vector>
#include <fstream>
using namespace std;
enum TUnite{
    BIN_OP,
    PT,
    BIN_COMP,
    NON,
    COMMENT,
    AND,
    OR,
    AFF,
    CROCH_OUV,
    CROCH_FER,
    PAR_OUV,
    PAR_FER,
    VERG,
    ACC_OUV,
    ACC_FER,
    PT_VER,
    MOT_CLE,
    MOT_RESERVE,
    NOMBRE,
    IDENT,FIN,
    VAR,
    VARSTRUCT,
    VARTAB,
    VARDESTRUCT,
    AUTRE,ERROR
};
typedef struct TUniteLexical{
    string UL;
    int attribut;
}TUniteLexical;
//std::ofstream fluxXML;
class analyseur_semantique
{
public:
analyseur_semantique(string s);
// R1
void programme();
// R2
void listeDeclarations();
void listeDeclarationsPrime();
void listeDeclarationsSimple();
void listeDeclarationsSimplePrime();
// R3
void declaration();
void declarationPrime();
void declarationSimple();
void declarationSimplePrime();
void declarateurSimple();
void declarateurCompose();
void declarateurComposePrime();
// R4
void listeFonctions();
void listeFonctionsPrime();
// R5
void fonction();
void fonctionPrime();
void fonctionSecond();
// R8
void listeParms();
void listeParmsPrime();
// R9
void parm();
//10
void bloc();
void blocmain();
void blocfaire();
void blocalors();
void blocPrime();
// R11
void listeInstructions();
void listeInstructionsPrime();
// R12
void instruction();
// R13
void iteration();
// R14
void selection();
void selectionPrime();
// R15
void saut();
// R16
void affectation();
void affectationPrime();
// R17
// R18
void appel();
// R19
void variable();
void variablePrime();
void variableSecond();
void variablestruct();
void variabletab();
// R20
void expression();
void expressionPrime();
// R21
void listeExpressions();
void listeExpressionsPrime();
void terme();
// R22;
void condition();
void conditionPrime();
// R23
void nombre();
void nombrePrime();
void identificateur();
void identificateurPrime();
void binaryOp();
// R24
void binaryRel();
// R25
void binaryComp();
void finsyntax();
void readfichier();
void fin();
void affiche(TUniteLexical ul1);
void ULIdentif(string lexeme);
void uniteSuivante();
bool estBlanc(char c);
int getIndexIdentif(string stringToFind, vector<string> stringArray);
int getIndex(string stringToFind, vector<string> stringArray);
int estMotcle(string lexeme);
int estMotreserve(string lexeme);
void Identif(char C, string s);
int returntokens(int j);
int Size();
char lc();
void manipulerVariables();
void declareDeja();
string getTypeIdentif(string s);
void UtiliseNonDeclare();
void RetourFonction();
//ofstream fluxXML;
    protected:

    private:
    char c=' ';string Str;int test=0;int nb=0;int nb1=0;int nb2=0;
    int motCourant;vector<int> tokens;
    int parcourir;int nbErreur;int Erreur;
    ofstream monFlux{"ProgrammeTest.txt"};
    ofstream fluxXML{"ArbreDerivation.txt"};
    vector<int> TableauEntier;
    vector<int> TableauStruct;
    vector<string> VariableDeclare;
    vector<string> TableauLexemes;
    vector<string> TypesIdentifiants;
    vector<string> identifiants;
    vector<string> identificateurs;
    vector<string> Variablestruct;
    vector<string> Variabletab;
    vector<string> variables;
    //table des mot-cl�s
    vector<string> motsCles={"sinon","alors","si","tantque","faire","entier","retour","struct"};
    //table des mot-r�s�rv�s
    vector<string> motsReserves={"lire","ecrire","main"};
    //table des operateurs binaires
    vector<string> binOp={"+","-","*","/"};
    //table des comparateurs binaires
    vector<string> binComp={"<",">","<=",">=","==","!="};

};
#endif // ANALYSEUR_SEMANTIQUE_H
