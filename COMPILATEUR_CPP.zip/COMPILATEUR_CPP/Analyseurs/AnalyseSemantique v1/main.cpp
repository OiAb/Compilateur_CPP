//OUIJDANE Abchir
#include <iostream>
#include "analyseur_semantique.h"
#include <string>
#include <fstream>
using namespace std;

int main()
{
    string str="entier e[10],entier j,struct var{entier k,entier m;};struct bar{entier h,entier g;};entier bar;somme(entier a,entier b)entier d[10];{d=a+somme;retour d;}main()entier somme,struct var{entier i,entier p;};{e[0]= 153;var=lire();ecrire(c);}";
    analyseur_semantique Semant(str);Semant.readfichier();Semant.uniteSuivante();
    return 0;

}
